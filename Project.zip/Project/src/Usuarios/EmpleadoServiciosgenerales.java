package Usuarios;

import LugarServicios.LugarServicio;

public class EmpleadoServiciosgenerales extends Empleado {
	
	private static final long serialVersionUID = 1L;
	
	private LugarServicio lugar;
	public EmpleadoServiciosgenerales (String login, String password, int edad, float altura) {
		super(login, password, edad, altura, "serviciosGenerales", "");
		this.AsignarTurno("N/A");
		this.lugar=null;
	}
	
	public LugarServicio getLugar() {
		return lugar;
	}
	
	public void setLugar(LugarServicio lugare) {
		lugar=lugare;
	}
}
