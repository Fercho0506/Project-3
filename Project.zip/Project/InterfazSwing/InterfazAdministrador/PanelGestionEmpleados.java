package InterfazAdministrador;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import LugarServicios.LugarServicio;
import Modelo.Parque;
import Usuarios.Administrador;
import Usuarios.Empleado;
import Usuarios.Usuario;

import java.awt.*;
import java.util.List;

public class PanelGestionEmpleados extends JPanel {

    private static final long serialVersionUID = 1L;
    private JTable tablaEmpleados;
    private DefaultTableModel modeloTabla;
    private Parque parque;
    private Administrador administrador;

    public PanelGestionEmpleados(Parque parque,Administrador administrador) {
    	this.administrador=administrador;
        this.parque = parque;

        setLayout(new BorderLayout());

        modeloTabla = new DefaultTableModel(new String[]{"Nombre", "Rol", "Labor"}, 0);
        tablaEmpleados = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tablaEmpleados);

        JPanel panelBotones = new JPanel();
        JButton btnAgregar = new JButton("Agregar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");

        btnAgregar.addActionListener(_ -> agregarEmpleado());
        btnEditar.addActionListener(_ -> editarEmpleado());
        btnEliminar.addActionListener(_ -> eliminarEmpleado());

        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);

        add(new JLabel("Gestión de Empleados", SwingConstants.CENTER), BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);

        cargarEmpleados();
    }

    private void cargarEmpleados() {
        modeloTabla.setRowCount(0);
        List<Empleado> empleados = parque.getEmpleados();
        for (Empleado emp : empleados) {
            modeloTabla.addRow(new Object[]{emp.getUsuario(), emp.gettipo(), emp.getLabor()});
        }
    }

    private void agregarEmpleado() {
        try {
            String nombre = JOptionPane.showInputDialog("Usuario del empleado:");
            String password= JOptionPane.showInputDialog("Contraseña del empleado:");
            String altura=JOptionPane.showInputDialog("Altura (ej: 1.75):");
            String edad= JOptionPane.showInputDialog("Edad empleado:");
            String rol = JOptionPane.showInputDialog("Tipo del empleado:");
            String labor = JOptionPane.showInputDialog("Labor del empleado (Sin labor dejar vacío):");

            if (nombre == null || rol == null || labor == null || nombre.isBlank() || rol.isBlank()) {
                JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
                return;
            }
            try {
            	parque.crearEmpleado(nombre, rol, labor, password, altura, edad, administrador); // Método en Parque
                cargarEmpleados();
            } catch (Exception e) {
            	System.out.print(e.getMessage());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al agregar empleado: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editarEmpleado() {
        int fila = tablaEmpleados.getSelectedRow();
        if (fila != -1) {
            String id = (String) modeloTabla.getValueAt(fila, 1);
            Empleado emp = (Empleado)parque.getUsuario(id); // Método auxiliar en Parque

            if (emp != null) {
                String nuevaLabor = JOptionPane.showInputDialog("Nueva labor:", emp.getLabor());

                if (nuevaLabor != null && !nuevaLabor.isBlank()) {
                	LugarServicio lugar= null;
                	if (!parque.getLugares().isEmpty()) {
                		lugar=parque.getLugares().get(0);
                	}
                	try {
                		administrador.AsignarLabor(emp, nuevaLabor, lugar);
                		cargarEmpleados();
                	}
                	catch (Exception e) {
                		System.out.print(e.getMessage());
                	}
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado para editar.");
        }
    }

    private void eliminarEmpleado() {
        int fila = tablaEmpleados.getSelectedRow();
        if (fila != -1) {
            Usuario usuario = parque.getUsuario((String) modeloTabla.getValueAt(fila, 1));
            parque.eliminarUsuario(usuario); // Método en Parque
            cargarEmpleados();
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado para eliminar.");
        }
    }
}
