package PanelesClientes;

public interface NotificationsListener{
	public void accionDesdePanel();
}
