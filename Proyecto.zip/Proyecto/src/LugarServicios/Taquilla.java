package LugarServicios;

public class Taquilla extends LugarServicio{
	private static final long serialVersionUID = 1L;
	public Taquilla(String nombre) {
		super("taquilla", nombre);
	}
}
